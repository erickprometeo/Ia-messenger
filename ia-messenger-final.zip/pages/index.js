import { useState } from 'react';

export default function Home() {
  const [messages, setMessages] = useState([]);
  const [input, setInput] = useState('');

  const sendMessage = () => {
    const newMessages = [...messages, { from: 'Tú', text: input }];
    setMessages(newMessages);
    setInput('');
    setTimeout(() => {
      setMessages([
        ...newMessages,
        { from: 'ChatGPT', text: '¿Qué noticia quieres generar ahora?' },
        { from: 'Grok', text: 'Aquí está lo último desde Internet.' }
      ]);
    }, 1000);
  };

  return (
    <div style={{ maxWidth: 600, margin: 'auto', padding: 20 }}>
      <h2>IA Messenger: ChatGPT y Grok</h2>
      <div style={{ border: '1px solid #ccc', padding: 10, minHeight: 300 }}>
        {messages.map((msg, i) => (
          <div key={i}><strong>{msg.from}:</strong> {msg.text}</div>
        ))}
      </div>
      <input
        value={input}
        onChange={(e) => setInput(e.target.value)}
        style={{ width: '100%', padding: 8, marginTop: 10 }}
      />
      <button onClick={sendMessage} style={{ marginTop: 10 }}>Enviar</button>
    </div>
  );
}
